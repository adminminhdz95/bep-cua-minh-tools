# 20 video từ vựng về buổi sáng

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-thuc-day-phan-1.mp4) | Thức dậy | 1 | morning, dawn, sunrise, alarm clock, wake up | 55.00s |
| [02](02-thuc-day-phan-2.mp4) | Thức dậy | 2 | get up, snooze, stretch, yawn, sleepy | 48.50s |
| [03](03-phong-ngu-phan-1.mp4) | Phòng ngủ và đón nắng | 1 | bedroom, bed, pillow, blanket, bedsheet | 48.83s |
| [04](04-phong-ngu-phan-2.mp4) | Phòng ngủ và đón nắng | 2 | mattress, curtains, sunlight, make the bed, open the curtains | 49.33s |
| [05](05-ve-sinh-ca-nhan-phan-1.mp4) | Vệ sinh cá nhân | 1 | bathroom, toothbrush, toothpaste, brush your teeth, mouthwash | 46.33s |
| [06](06-ve-sinh-ca-nhan-phan-2.mp4) | Vệ sinh cá nhân | 2 | wash your face, soap, towel, comb your hair, mirror | 46.67s |
| [07](07-tam-thay-do-phan-1.mp4) | Tắm và thay quần áo | 1 | shower, take a shower, shampoo, conditioner, deodorant | 51.00s |
| [08](08-tam-thay-do-phan-2.mp4) | Tắm và thay quần áo | 2 | get dressed, shirt, trousers, socks, shoes | 48.50s |
| [09](09-bua-sang-phan-1.mp4) | Bữa sáng | 1 | breakfast, bread, toast, egg, cereal | 48.00s |
| [10](10-bua-sang-phan-2.mp4) | Bữa sáng | 2 | oatmeal, yogurt, fruit, banana, apple | 45.83s |
| [11](11-do-uong-phan-1.mp4) | Đồ uống buổi sáng | 1 | water, milk, coffee, tea, orange juice | 45.00s |
| [12](12-do-uong-phan-2.mp4) | Đồ uống buổi sáng | 2 | smoothie, cup, mug, kettle, boil water | 60.17s |
| [13](13-nha-bep-phan-1.mp4) | Trong nhà bếp | 1 | kitchen, fridge, stove, frying pan, plate | 44.17s |
| [14](14-nha-bep-phan-2.mp4) | Trong nhà bếp | 2 | bowl, spoon, fork, knife, wash the dishes | 49.33s |
| [15](15-van-dong-phan-1.mp4) | Vận động buổi sáng | 1 | exercise, warm up, go for a walk, go jogging, do yoga | 49.33s |
| [16](16-van-dong-phan-2.mp4) | Vận động buổi sáng | 2 | breathe deeply, fresh air, park, energy, healthy | 48.00s |
| [17](17-chuan-bi-phan-1.mp4) | Chuẩn bị ngày mới | 1 | daily routine, schedule, to-do list, check the weather, pack your bag | 50.00s |
| [18](18-chuan-bi-phan-2.mp4) | Chuẩn bị ngày mới | 2 | keys, wallet, phone, umbrella, leave home | 47.67s |
| [19](19-di-lam-phan-1.mp4) | Đi học và đi làm | 1 | commute, bus stop, catch the bus, train station, ride a bike | 51.17s |
| [20](20-di-lam-phan-2.mp4) | Đi học và đi làm | 2 | drive to work, traffic, rush hour, arrive on time, start work | 74.50s |
