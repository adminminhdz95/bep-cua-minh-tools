# 20 video từ vựng về bệnh viện

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-nhan-vien-phan-1.mp4) | Nhân viên y tế | 1 | doctor, nurse, surgeon, dentist, pharmacist | 48.00s |
| [02](02-nhan-vien-phan-2.mp4) | Nhân viên y tế | 2 | midwife, paramedic, radiologist, anesthesiologist, physiotherapist | 50.67s |
| [03](03-khu-vuc-phan-1.mp4) | Khu vực trong bệnh viện | 1 | waiting room, operating room, emergency department, intensive care unit, maternity ward | 50.50s |
| [04](04-khu-vuc-phan-2.mp4) | Khu vực trong bệnh viện | 2 | reception desk, laboratory, pharmacy, examination room, recovery room | 53.00s |
| [05](05-dung-cu-phan-1.mp4) | Dụng cụ khám bệnh | 1 | stethoscope, thermometer, blood pressure monitor, pulse oximeter, reflex hammer | 51.83s |
| [06](06-dung-cu-phan-2.mp4) | Dụng cụ khám bệnh | 2 | otoscope, syringe, needle, tongue depressor, tweezers | 50.17s |
| [07](07-vat-dung-phan-1.mp4) | Vật dụng chăm sóc | 1 | bandage, gauze, medical tape, cotton ball, wound dressing | 55.00s |
| [08](08-vat-dung-phan-2.mp4) | Vật dụng chăm sóc | 2 | wheelchair, stretcher, crutch, walking frame, hospital bed | 54.50s |
| [09](09-trieu-chung-phan-1.mp4) | Triệu chứng thường gặp | 1 | fever, cough, headache, sore throat, stomachache | 46.17s |
| [10](10-trieu-chung-phan-2.mp4) | Triệu chứng thường gặp | 2 | dizziness, nausea, fatigue, shortness of breath, chest pain | 48.00s |
| [11](11-tinh-trang-phan-1.mp4) | Tình trạng sức khỏe | 1 | fracture, sprain, bruise, burn, cut | 46.33s |
| [12](12-tinh-trang-phan-2.mp4) | Tình trạng sức khỏe | 2 | infection, allergy, asthma, diabetes, anemia | 53.17s |
| [13](13-xet-nghiem-phan-1.mp4) | Khám và xét nghiệm | 1 | blood test, urine test, X-ray, ultrasound, CT scan | 55.83s |
| [14](14-xet-nghiem-phan-2.mp4) | Khám và xét nghiệm | 2 | MRI scan, electrocardiogram, biopsy, vision test, hearing test | 53.67s |
| [15](15-dieu-tri-phan-1.mp4) | Thuốc và điều trị | 1 | painkiller, antibiotic, antihistamine, antiseptic, vaccine | 55.33s |
| [16](16-dieu-tri-phan-2.mp4) | Thuốc và điều trị | 2 | ointment, eye drops, nasal spray, cough syrup, inhaler | 48.50s |
| [17](17-hoat-dong-phan-1.mp4) | Hoạt động tại bệnh viện | 1 | examine, diagnose, prescribe, vaccinate, disinfect | 46.33s |
| [18](18-hoat-dong-phan-2.mp4) | Hoạt động tại bệnh viện | 2 | admit, discharge, recover, rehabilitate, monitor | 56.17s |
| [19](19-ho-so-phan-1.mp4) | Hồ sơ và thông tin | 1 | appointment, prescription, medical record, referral letter, consent form | 48.83s |
| [20](20-ho-so-phan-2.mp4) | Hồ sơ và thông tin | 2 | insurance card, patient wristband, test result, hospital bill, discharge summary | 51.67s |
