# 20 video từ vựng về tâm trạng mỗi ngày

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-niem-vui-phan-1.mp4) | Niềm vui | 1 | happy, cheerful, joyful, delighted, content | 48.00s |
| [02](02-niem-vui-phan-2.mp4) | Niềm vui | 2 | pleased, upbeat, playful, amused, lighthearted | 48.50s |
| [03](03-noi-buon-phan-1.mp4) | Nỗi buồn | 1 | sad, unhappy, miserable, gloomy, heartbroken | 52.50s |
| [04](04-noi-buon-phan-2.mp4) | Nỗi buồn | 2 | lonely, homesick, nostalgic, tearful, downcast | 48.33s |
| [05](05-lo-lang-phan-1.mp4) | Lo lắng | 1 | worried, anxious, nervous, uneasy, restless | 48.83s |
| [06](06-lo-lang-phan-2.mp4) | Lo lắng | 2 | tense, stressed, panicky, insecure, apprehensive | 53.17s |
| [07](07-gian-du-phan-1.mp4) | Giận dữ | 1 | angry, annoyed, irritated, furious, frustrated | 50.67s |
| [08](08-gian-du-phan-2.mp4) | Giận dữ | 2 | resentful, bitter, grouchy, impatient, fed up | 50.33s |
| [09](09-binh-yen-phan-1.mp4) | Bình yên | 1 | calm, relaxed, peaceful, serene, relieved | 47.67s |
| [10](10-binh-yen-phan-2.mp4) | Bình yên | 2 | comfortable, grateful, hopeful, optimistic, reassured | 49.83s |
| [11](11-nang-luong-phan-1.mp4) | Năng lượng | 1 | energetic, lively, refreshed, alert, motivated | 50.33s |
| [12](12-nang-luong-phan-2.mp4) | Năng lượng | 2 | inspired, enthusiastic, eager, excited, exhilarated | 52.67s |
| [13](13-met-moi-phan-1.mp4) | Mệt mỏi | 1 | tired, exhausted, sleepy, drowsy, drained | 47.17s |
| [14](14-met-moi-phan-2.mp4) | Mệt mỏi | 2 | sluggish, bored, weary, burned out, listless | 49.83s |
| [15](15-bat-ngo-phan-1.mp4) | Bất ngờ và bối rối | 1 | surprised, amazed, astonished, shocked, confused | 48.00s |
| [16](16-bat-ngo-phan-2.mp4) | Bất ngờ và bối rối | 2 | puzzled, uncertain, indecisive, overwhelmed, curious | 50.50s |
| [17](17-cam-xuc-phan-1.mp4) | Cảm xúc với người khác | 1 | affectionate, loved, jealous, envious, sympathetic | 49.83s |
| [18](18-cam-xuc-phan-2.mp4) | Cảm xúc với người khác | 2 | embarrassed, ashamed, guilty, proud, accepted | 48.00s |
| [19](19-doi-mat-phan-1.mp4) | Đối mặt mỗi ngày | 1 | confident, shy, vulnerable, disappointed, discouraged | 50.67s |
| [20](20-doi-mat-phan-2.mp4) | Đối mặt mỗi ngày | 2 | determined, hesitant, regretful, doubtful, satisfied | 50.67s |
