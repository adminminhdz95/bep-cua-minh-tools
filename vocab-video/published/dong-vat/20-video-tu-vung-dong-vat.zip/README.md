# 20 video từ vựng về động vật

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-thu-cung-phan-1.mp4) | Thú cưng | 1 | dog, cat, hamster, guinea pig, rabbit | 44.50s |
| [02](02-thu-cung-phan-2.mp4) | Thú cưng | 2 | goldfish, parrot, budgie, canary, gerbil | 46.33s |
| [03](03-trang-trai-phan-1.mp4) | Động vật ở trang trại | 1 | cow, bull, calf, goat, sheep | 45.33s |
| [04](04-trang-trai-phan-2.mp4) | Động vật ở trang trại | 2 | lamb, pig, horse, donkey, duck | 44.17s |
| [05](05-san-moi-phan-1.mp4) | Thú săn mồi | 1 | lion, tiger, leopard, cheetah, jaguar | 44.50s |
| [06](06-san-moi-phan-2.mp4) | Thú săn mồi | 2 | hyena, wolf, fox, jackal, polar bear | 43.67s |
| [07](07-hoang-da-phan-1.mp4) | Thú hoang dã quen thuộc | 1 | elephant, giraffe, zebra, hippopotamus, rhinoceros | 42.33s |
| [08](08-hoang-da-phan-2.mp4) | Thú hoang dã quen thuộc | 2 | camel, kangaroo, koala, panda, sloth | 45.00s |
| [09](09-trong-rung-phan-1.mp4) | Động vật trong rừng | 1 | brown bear, deer, moose, reindeer, squirrel | 45.00s |
| [10](10-trong-rung-phan-2.mp4) | Động vật trong rừng | 2 | raccoon, badger, hedgehog, bat, monkey | 45.83s |
| [11](11-loai-chim-phan-1.mp4) | Các loài chim | 1 | eagle, hawk, owl, crow, sparrow | 44.50s |
| [12](12-loai-chim-phan-2.mp4) | Các loài chim | 2 | pigeon, woodpecker, peacock, ostrich, hummingbird | 45.00s |
| [13](13-chim-gan-nuoc-phan-1.mp4) | Chim sống gần nước | 1 | swan, goose, penguin, flamingo, pelican | 44.50s |
| [14](14-chim-gan-nuoc-phan-2.mp4) | Chim sống gần nước | 2 | stork, heron, crane, seagull, puffin | 48.50s |
| [15](15-bo-sat-phan-1.mp4) | Bò sát và lưỡng cư | 1 | crocodile, alligator, snake, lizard, gecko | 45.83s |
| [16](16-bo-sat-phan-2.mp4) | Bò sát và lưỡng cư | 2 | chameleon, iguana, tortoise, frog, toad | 42.83s |
| [17](17-bien-phan-1.mp4) | Động vật biển | 1 | dolphin, whale, shark, seal, walrus | 44.17s |
| [18](18-bien-phan-2.mp4) | Động vật biển | 2 | octopus, squid, jellyfish, seahorse, stingray | 44.17s |
| [19](19-con-trung-phan-1.mp4) | Côn trùng và nhện | 1 | ant, bee, wasp, butterfly, moth | 45.00s |
| [20](20-con-trung-phan-2.mp4) | Côn trùng và nhện | 2 | mosquito, fly, dragonfly, grasshopper, spider | 42.33s |
