# 20 video từ vựng về gia đình

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-nguoi-than-phan-1.mp4) | Người thân gần gũi | 1 | father, mother, brother, sister, son | 54.50s |
| [02](02-nguoi-than-phan-2.mp4) | Người thân gần gũi | 2 | daughter, uncle, aunt, nephew, niece | 72.00s |
| [03](03-mo-rong-phan-1.mp4) | Ông bà và gia đình mở rộng | 1 | grandfather, grandmother, grandson, granddaughter, father-in-law | 53.67s |
| [04](04-mo-rong-phan-2.mp4) | Ông bà và gia đình mở rộng | 2 | mother-in-law, brother-in-law, sister-in-law, stepfather, stepmother | 85.33s |
| [05](05-vai-tro-phan-1.mp4) | Vợ chồng và con cái | 1 | husband, wife, cousin, twins, only child | 54.17s |
| [06](06-vai-tro-phan-2.mp4) | Vợ chồng và con cái | 2 | eldest child, youngest child, middle child, teenager, toddler | 58.67s |
| [07](07-dip-dac-biet-phan-1.mp4) | Dịp đặc biệt trong gia đình | 1 | birthday, wedding, wedding anniversary, engagement, family reunion | 52.67s |
| [08](08-dip-dac-biet-phan-2.mp4) | Dịp đặc biệt trong gia đình | 2 | funeral, graduation ceremony, birth, baptism, housewarming party | 50.00s |
| [09](09-cuoc-song-phan-1.mp4) | Cuộc sống gia đình | 1 | marriage, divorce, adoption, pregnancy, childhood | 49.83s |
| [10](10-cuoc-song-phan-2.mp4) | Cuộc sống gia đình | 2 | parenthood, upbringing, household, family tree, generation | 53.00s |
| [11](11-tinh-trang-phan-1.mp4) | Tình trạng và quan hệ | 1 | single, married, divorced, widowed, engaged | 55.83s |
| [12](12-tinh-trang-phan-2.mp4) | Tình trạng và quan hệ | 2 | pregnant, newborn, adopted, biological, foster | 55.00s |
| [13](13-tinh-cach-phan-1.mp4) | Tính cách người thân | 1 | kind, caring, strict, patient, generous | 48.83s |
| [14](14-tinh-cach-phan-2.mp4) | Tính cách người thân | 2 | cheerful, shy, stubborn, polite, responsible | 48.50s |
| [15](15-sinh-hoat-phan-1.mp4) | Sinh hoạt cùng nhau | 1 | have dinner together, cook a meal, wash the dishes, set the table, clear the table | 52.00s |
| [16](16-sinh-hoat-phan-2.mp4) | Sinh hoạt cùng nhau | 2 | do the laundry, fold the clothes, clean the house, take out the trash, go grocery shopping | 52.00s |
| [17](17-cham-con-phan-1.mp4) | Chăm sóc con cái | 1 | feed the baby, change a diaper, bathe the baby, put the baby to bed, read a bedtime story | 50.67s |
| [18](18-cham-con-phan-2.mp4) | Chăm sóc con cái | 2 | help with homework, take the children to school, pick up the children, play with the children, teach good manners | 54.50s |
| [19](19-gan-ket-phan-1.mp4) | Gắn kết gia đình | 1 | visit relatives, call your parents, hug your child, apologize to your sister, thank your mother | 53.50s |
| [20](20-gan-ket-phan-2.mp4) | Gắn kết gia đình | 2 | listen to your father, share your feelings, keep a promise, solve a family problem, plan a family trip | 58.83s |
