# 20 video từ vựng về trường học

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-con-nguoi-phan-1.mp4) | Những người ở trường | 1 | teacher, student, principal, librarian, classmate | 45.00s |
| [02](02-con-nguoi-phan-2.mp4) | Những người ở trường | 2 | teaching assistant, coach, school nurse, school counselor, caretaker | 51.00s |
| [03](03-dia-diem-phan-1.mp4) | Địa điểm trong trường | 1 | classroom, library, playground, cafeteria, laboratory | 44.50s |
| [04](04-dia-diem-phan-2.mp4) | Địa điểm trong trường | 2 | gymnasium, computer room, art room, music room, auditorium | 44.17s |
| [05](05-do-dung-phan-1.mp4) | Đồ dùng học tập | 1 | pencil, pen, eraser, ruler, notebook | 47.17s |
| [06](06-do-dung-phan-2.mp4) | Đồ dùng học tập | 2 | textbook, backpack, pencil case, pencil sharpener, folder | 47.17s |
| [07](07-trong-lop-phan-1.mp4) | Đồ vật trong lớp | 1 | desk, chair, whiteboard, blackboard, chalk | 44.50s |
| [08](08-trong-lop-phan-2.mp4) | Đồ vật trong lớp | 2 | marker, projector, screen, clock, globe | 44.17s |
| [09](09-mon-hoc-phan-1.mp4) | Các môn học | 1 | mathematics, English, Vietnamese, science, history | 43.33s |
| [10](10-mon-hoc-phan-2.mp4) | Các môn học | 2 | geography, music, art, physical education, information technology | 51.33s |
| [11](11-thoi-gian-phan-1.mp4) | Thời gian và nề nếp | 1 | lesson, timetable, break, school assembly, attendance | 48.50s |
| [12](12-thoi-gian-phan-2.mp4) | Thời gian và nề nếp | 2 | semester, school day, school holiday, lunchtime, deadline | 46.67s |
| [13](13-bai-tap-phan-1.mp4) | Bài tập và đánh giá | 1 | homework, worksheet, report card, certificate, question | 45.33s |
| [14](14-bai-tap-phan-2.mp4) | Bài tập và đánh giá | 2 | answer, score, mistake, spelling test, final exam | 48.50s |
| [15](15-ky-nang-phan-1.mp4) | Kỹ năng học tập | 1 | read, write, listen, speak, count | 41.17s |
| [16](16-ky-nang-phan-2.mp4) | Kỹ năng học tập | 2 | spell, draw, calculate, memorize, revise | 43.67s |
| [17](17-hoat-dong-phan-1.mp4) | Hoạt động trong lớp | 1 | raise your hand, open your book, close your book, turn the page, take notes | 48.00s |
| [18](18-hoat-dong-phan-2.mp4) | Hoạt động trong lớp | 2 | ask a question, answer a question, work in pairs, hand in your homework, line up | 45.00s |
| [19](19-trang-thai-phan-1.mp4) | Trạng thái trong lớp | 1 | absent, present, late, early, quiet | 43.33s |
| [20](20-trang-thai-phan-2.mp4) | Trạng thái trong lớp | 2 | noisy, correct, incorrect, easy, difficult | 47.67s |
