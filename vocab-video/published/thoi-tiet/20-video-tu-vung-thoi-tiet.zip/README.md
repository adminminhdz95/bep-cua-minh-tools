# 20 video từ vựng về thời tiết

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-mo-ta-phan-1.mp4) | Mô tả thời tiết | 1 | sunny, rainy, cloudy, windy, foggy | 47.17s |
| [02](02-mo-ta-phan-2.mp4) | Mô tả thời tiết | 2 | snowy, stormy, clear, overcast, changeable | 55.83s |
| [03](03-nhiet-do-phan-1.mp4) | Nhiệt độ và cảm giác | 1 | hot, cold, warm, cool, freezing | 44.00s |
| [04](04-nhiet-do-phan-2.mp4) | Nhiệt độ và cảm giác | 2 | chilly, mild, humid, muggy, scorching | 48.83s |
| [05](05-mua-phan-1.mp4) | Mưa và nước | 1 | rain, drizzle, downpour, shower, raindrop | 58.17s |
| [06](06-mua-phan-2.mp4) | Mưa và nước | 2 | rainfall, puddle, flood, rainbow, rainwater | 47.67s |
| [07](07-gio-bao-phan-1.mp4) | Gió và bão | 1 | wind, breeze, gust, gale, storm | 47.50s |
| [08](08-gio-bao-phan-2.mp4) | Gió và bão | 2 | thunderstorm, thunder, lightning, tornado, typhoon | 58.00s |
| [09](09-tuyet-bang-phan-1.mp4) | Tuyết và băng | 1 | snow, snowflake, snowfall, blizzard, ice | 52.33s |
| [10](10-tuyet-bang-phan-2.mp4) | Tuyết và băng | 2 | icicle, frost, hail, sleet, snowdrift | 55.00s |
| [11](11-bau-troi-phan-1.mp4) | Bầu trời và ánh sáng | 1 | sky, cloud, sun, sunshine, sunrise | 47.17s |
| [12](12-bau-troi-phan-2.mp4) | Bầu trời và ánh sáng | 2 | sunset, moon, star, horizon, sunlight | 51.33s |
| [13](13-mua-khi-hau-phan-1.mp4) | Mùa và khí hậu | 1 | spring, summer, autumn, winter, rainy season | 47.17s |
| [14](14-mua-khi-hau-phan-2.mp4) | Mùa và khí hậu | 2 | dry season, climate, drought, heatwave, cold spell | 51.50s |
| [15](15-du-bao-phan-1.mp4) | Dự báo thời tiết | 1 | weather forecast, temperature, humidity, air pressure, wind speed | 49.67s |
| [16](16-du-bao-phan-2.mp4) | Dự báo thời tiết | 2 | wind direction, visibility, weather warning, chance of rain, UV index | 49.83s |
| [17](17-cum-tu-phan-1.mp4) | Cụm từ thường dùng | 1 | check the forecast, carry an umbrella, put on a raincoat, wear sunscreen, stay in the shade | 51.83s |
| [18](18-cum-tu-phan-2.mp4) | Cụm từ thường dùng | 2 | take shelter, close the windows, turn on the fan, keep warm, drink plenty of water | 50.17s |
| [19](19-dac-diem-phan-1.mp4) | Đặc điểm thời tiết | 1 | dry, wet, icy, slippery, dusty | 49.83s |
| [20](20-dac-diem-phan-2.mp4) | Đặc điểm thời tiết | 2 | misty, hazy, breezy, damp, unsettled | 52.33s |
