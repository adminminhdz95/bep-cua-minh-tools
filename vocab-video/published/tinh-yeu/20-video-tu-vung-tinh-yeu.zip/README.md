# 20 video từ vựng về tình yêu

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Thời lượng phần đọc được tăng khi cần, không cắt âm thanh.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-cam-xuc-phan-1.mp4) | Cảm xúc tình yêu | 1 | love, affection, attraction, fondness, admiration | 30.50s |
| [02](02-cam-xuc-phan-2.mp4) | Cảm xúc tình yêu | 2 | passion, desire, longing, tenderness, intimacy | 30.00s |
| [03](03-nguoi-trong-moi-quan-he-phan-1.mp4) | Người trong mối quan hệ | 1 | crush, boyfriend, girlfriend, partner, lover | 30.50s |
| [04](04-nguoi-trong-moi-quan-he-phan-2.mp4) | Người trong mối quan hệ | 2 | sweetheart, soulmate, significant other, fiancé, fiancée | 32.17s |
| [05](05-bat-dau-yeu-phan-1.mp4) | Bắt đầu yêu | 1 | flirt, flirtation, fall in love, have a crush on, be attracted to | 31.67s |
| [06](06-bat-dau-yeu-phan-2.mp4) | Bắt đầu yêu | 2 | ask someone out, go on a date, confess your feelings, love at first sight, chemistry | 31.67s |
| [07](07-hen-ho-phan-1.mp4) | Hẹn hò và tìm hiểu | 1 | date, dating, relationship, courtship, romance | 30.00s |
| [08](08-hen-ho-phan-2.mp4) | Hẹn hò và tìm hiểu | 2 | romantic, get to know someone, spend time together, see someone, long-distance relationship | 33.67s |
| [09](09-the-hien-tinh-cam-phan-1.mp4) | Hành động thể hiện tình cảm | 1 | kiss, hug, cuddle, embrace, hold hands | 30.83s |
| [10](10-the-hien-tinh-cam-phan-2.mp4) | Hành động thể hiện tình cảm | 2 | caress, cherish, adore, comfort, care for | 30.00s |
| [11](11-tinh-yeu-ben-vung-phan-1.mp4) | Tình yêu bền vững | 1 | trust, respect, honesty, loyalty, commitment | 30.00s |
| [12](12-tinh-yeu-ben-vung-phan-2.mp4) | Tình yêu bền vững | 2 | devotion, understanding, support, compromise, forgiveness | 30.83s |
| [13](13-tinh-cach-phan-1.mp4) | Tính cách và phẩm chất | 1 | loving, caring, affectionate, thoughtful, considerate | 30.00s |
| [14](14-tinh-cach-phan-2.mp4) | Tính cách và phẩm chất | 2 | faithful, devoted, sincere, compatible, considerate partner | 32.83s |
| [15](15-cau-hon-ket-hon-phan-1.mp4) | Cầu hôn và kết hôn | 1 | propose, proposal, engagement, engagement ring, wedding | 32.50s |
| [16](16-cau-hon-ket-hon-phan-2.mp4) | Cầu hôn và kết hôn | 2 | bride, groom, marriage, wedding vows, honeymoon | 30.00s |
| [17](17-kho-khan-phan-1.mp4) | Khó khăn trong tình yêu | 1 | jealousy, insecurity, misunderstanding, argument, conflict | 32.83s |
| [18](18-kho-khan-phan-2.mp4) | Khó khăn trong tình yêu | 2 | betrayal, infidelity, unrequited love, heartbreak, heartbroken | 33.33s |
| [19](19-chia-tay-phan-1.mp4) | Chia tay và bước tiếp | 1 | break up, breakup, ex-partner, separation, divorce | 30.83s |
| [20](20-chia-tay-phan-2.mp4) | Chia tay và bước tiếp | 2 | reconciliation, make up, get back together, move on, let go | 30.00s |
