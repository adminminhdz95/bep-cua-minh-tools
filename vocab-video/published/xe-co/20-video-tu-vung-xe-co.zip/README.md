# 20 video từ vựng về xe cộ

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-duong-bo-phan-1.mp4) | Xe đường bộ | 1 | car, motorcycle, bicycle, truck, van | 43.67s |
| [02](02-duong-bo-phan-2.mp4) | Xe đường bộ | 2 | ambulance, fire engine, police car, tractor, bulldozer | 47.50s |
| [03](03-cong-cong-phan-1.mp4) | Phương tiện công cộng | 1 | bus, train, tram, subway, coach | 51.17s |
| [04](04-cong-cong-phan-2.mp4) | Phương tiện công cộng | 2 | taxi, double-decker, school bus, trolleybus, cable car | 53.67s |
| [05](05-thuy-hang-khong-phan-1.mp4) | Đường thủy và hàng không | 1 | airplane, helicopter, hot-air balloon, glider, seaplane | 49.67s |
| [06](06-thuy-hang-khong-phan-2.mp4) | Đường thủy và hàng không | 2 | ferry, canoe, sailboat, submarine, speedboat | 46.67s |
| [07](07-ben-ngoai-phan-1.mp4) | Bộ phận bên ngoài xe | 1 | wheel, tire, door, windshield, headlight | 46.33s |
| [08](08-ben-ngoai-phan-2.mp4) | Bộ phận bên ngoài xe | 2 | taillight, bumper, hood, trunk, license plate | 49.83s |
| [09](09-thiet-bi-phan-1.mp4) | Bộ phận và thiết bị | 1 | engine, steering wheel, brake, clutch, gear stick | 46.67s |
| [10](10-thiet-bi-phan-2.mp4) | Bộ phận và thiết bị | 2 | seat belt, horn, rearview mirror, speedometer, fuel tank | 50.67s |
| [11](11-duong-sa-phan-1.mp4) | Đường sá | 1 | intersection, roundabout, sidewalk, crosswalk, traffic light | 49.83s |
| [12](12-duong-sa-phan-2.mp4) | Đường sá | 2 | traffic sign, lane, tunnel, bridge, speed bump | 49.33s |
| [13](13-con-nguoi-phan-1.mp4) | Người tham gia giao thông | 1 | driver, passenger, pedestrian, cyclist, motorcyclist | 47.17s |
| [14](14-con-nguoi-phan-2.mp4) | Người tham gia giao thông | 2 | pilot, flight attendant, mechanic, traffic officer, ship captain | 43.67s |
| [15](15-hoat-dong-phan-1.mp4) | Hoạt động với xe | 1 | accelerate, decelerate, park, overtake, reverse | 47.50s |
| [16](16-hoat-dong-phan-2.mp4) | Hoạt động với xe | 2 | refuel, honk, steer, fasten, unfasten | 47.50s |
| [17](17-hanh-trinh-phan-1.mp4) | Hành trình và dịch vụ | 1 | ticket, fare, route, schedule, bus stop | 45.33s |
| [18](18-hanh-trinh-phan-2.mp4) | Hành trình và dịch vụ | 2 | train station, airport, parking lot, gas station, repair shop | 46.00s |
| [19](19-dac-diem-phan-1.mp4) | Đặc điểm khi di chuyển | 1 | fast, slow, safe, dangerous, crowded | 43.67s |
| [20](20-dac-diem-phan-2.mp4) | Đặc điểm khi di chuyển | 2 | empty, comfortable, uncomfortable, punctual, delayed | 46.67s |
