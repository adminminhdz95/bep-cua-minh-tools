# 20 video từ vựng về đồ uống

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-nuoc-uong-phan-1.mp4) | Nước uống | 1 | water, drinking water, tap water, mineral water, spring water | 54.17s |
| [02](02-nuoc-uong-phan-2.mp4) | Nước uống | 2 | still water, sparkling water, filtered water, bottled water, coconut water | 51.50s |
| [03](03-tra-phan-1.mp4) | Các loại trà | 1 | tea, black tea, green tea, oolong tea, herbal tea | 50.17s |
| [04](04-tra-phan-2.mp4) | Các loại trà | 2 | chamomile tea, jasmine tea, ginger tea, peppermint tea, iced tea | 51.50s |
| [05](05-ca-phe-phan-1.mp4) | Các loại cà phê | 1 | coffee, espresso, americano, cappuccino, latte | 59.67s |
| [06](06-ca-phe-phan-2.mp4) | Các loại cà phê | 2 | mocha, decaf coffee, instant coffee, cold brew, iced coffee | 57.50s |
| [07](07-nuoc-ep-phan-1.mp4) | Nước ép | 1 | juice, orange juice, apple juice, pineapple juice, grape juice | 49.00s |
| [08](08-nuoc-ep-phan-2.mp4) | Nước ép | 2 | watermelon juice, carrot juice, tomato juice, sugarcane juice, lemon juice | 48.83s |
| [09](09-sua-phan-1.mp4) | Sữa và đồ uống từ thực vật | 1 | milk, whole milk, skimmed milk, soy milk, almond milk | 47.50s |
| [10](10-sua-phan-2.mp4) | Sữa và đồ uống từ thực vật | 2 | oat milk, coconut milk, chocolate milk, strawberry milk, condensed milk | 49.33s |
| [11](11-do-uong-phan-1.mp4) | Đồ uống đa dạng | 1 | soft drink, soda, lemonade, smoothie, milkshake | 50.17s |
| [12](12-do-uong-phan-2.mp4) | Đồ uống đa dạng | 2 | hot chocolate, bubble tea, sports drink, energy drink, mocktail | 56.83s |
| [13](13-nguyen-lieu-phan-1.mp4) | Nguyên liệu pha chế | 1 | ice, sugar, honey, syrup, lemon | 48.00s |
| [14](14-nguyen-lieu-phan-2.mp4) | Nguyên liệu pha chế | 2 | lime, mint, cinnamon, cocoa powder, creamer | 52.33s |
| [15](15-dung-cu-phan-1.mp4) | Ly cốc và dụng cụ | 1 | cup, mug, glass, bottle, straw | 51.00s |
| [16](16-dung-cu-phan-2.mp4) | Ly cốc và dụng cụ | 2 | lid, coaster, pitcher, teapot, thermos | 50.17s |
| [17](17-mo-ta-phan-1.mp4) | Mô tả đồ uống | 1 | hot, cold, warm, lukewarm, chilled | 52.83s |
| [18](18-mo-ta-phan-2.mp4) | Mô tả đồ uống | 2 | sweet, bitter, fizzy, refreshing, diluted | 51.00s |
| [19](19-pha-uong-phan-1.mp4) | Pha và thưởng thức | 1 | pour, stir, sip, gulp, brew | 59.83s |
| [20](20-pha-uong-phan-2.mp4) | Pha và thưởng thức | 2 | steep, squeeze, shake, refill, order | 59.33s |
