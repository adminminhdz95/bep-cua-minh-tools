# 20 video từ vựng về đồ vật thiết yếu trong nhà

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-phong-khach-phan-1.mp4) | Nội thất phòng khách | 1 | sofa, armchair, coffee table, bookshelf, TV stand | 47.50s |
| [02](02-phong-khach-phan-2.mp4) | Nội thất phòng khách | 2 | rug, curtain, cushion, floor lamp, wall clock | 48.00s |
| [03](03-phong-ngu-phan-1.mp4) | Đồ dùng phòng ngủ | 1 | bed, mattress, pillow, blanket, bedsheet | 48.83s |
| [04](04-phong-ngu-phan-2.mp4) | Đồ dùng phòng ngủ | 2 | pillowcase, wardrobe, hanger, bedside table, alarm clock | 50.67s |
| [05](05-ban-an-phan-1.mp4) | Đồ dùng bàn ăn | 1 | dining table, chair, plate, bowl, spoon | 47.67s |
| [06](06-ban-an-phan-2.mp4) | Đồ dùng bàn ăn | 2 | fork, chopsticks, glass, mug, napkin | 46.33s |
| [07](07-nau-an-phan-1.mp4) | Dụng cụ nấu ăn | 1 | pot, frying pan, lid, kitchen knife, cutting board | 48.50s |
| [08](08-nau-an-phan-2.mp4) | Dụng cụ nấu ăn | 2 | ladle, spatula, colander, peeler, kitchen scissors | 51.50s |
| [09](09-thiet-bi-bep-phan-1.mp4) | Thiết bị nhà bếp | 1 | refrigerator, freezer, rice cooker, microwave, oven | 47.17s |
| [10](10-thiet-bi-bep-phan-2.mp4) | Thiết bị nhà bếp | 2 | stove, electric kettle, blender, toaster, range hood | 53.67s |
| [11](11-phong-tam-phan-1.mp4) | Đồ dùng phòng tắm | 1 | toothbrush, toothpaste, soap, shampoo, body wash | 46.33s |
| [12](12-phong-tam-phan-2.mp4) | Đồ dùng phòng tắm | 2 | towel, comb, mirror, toilet paper, bath mat | 47.50s |
| [13](13-don-dep-phan-1.mp4) | Dọn dẹp và giặt giũ | 1 | broom, dustpan, mop, bucket, sponge | 48.83s |
| [14](14-don-dep-phan-2.mp4) | Dọn dẹp và giặt giũ | 2 | trash can, trash bag, laundry basket, washing machine, laundry detergent | 52.67s |
| [15](15-dien-gia-dung-phan-1.mp4) | Điện và thiết bị gia đình | 1 | light bulb, light switch, power outlet, extension cord, phone charger | 53.17s |
| [16](16-dien-gia-dung-phan-2.mp4) | Điện và thiết bị gia đình | 2 | battery, remote control, fan, air conditioner, vacuum cleaner | 51.17s |
| [17](17-cat-giu-phan-1.mp4) | Cất giữ và đồ dùng nhỏ | 1 | storage box, basket, drawer, shoe rack, key | 48.00s |
| [18](18-cat-giu-phan-2.mp4) | Cất giữ và đồ dùng nhỏ | 2 | door lock, doormat, water bottle, tissue box, food container | 51.50s |
| [19](19-an-toan-phan-1.mp4) | Đồ sửa chữa và an toàn | 1 | flashlight, first aid kit, thermometer, fire extinguisher, smoke detector | 48.50s |
| [20](20-an-toan-phan-2.mp4) | Đồ sửa chữa và an toàn | 2 | hammer, screwdriver, pliers, tape measure, adhesive tape | 46.33s |
