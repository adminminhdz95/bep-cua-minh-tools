# 20 video từ vựng về quần áo đơn giản

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-cac-loai-ao-phan-1.mp4) | Các loại áo | 1 | shirt, T-shirt, polo shirt, blouse, tank top | 49.67s |
| [02](02-cac-loai-ao-phan-2.mp4) | Các loại áo | 2 | sweater, sweatshirt, hoodie, cardigan, vest | 51.50s |
| [03](03-quan-vay-phan-1.mp4) | Quần váy và bộ đồ | 1 | trousers, jeans, shorts, skirt, dress | 50.17s |
| [04](04-quan-vay-phan-2.mp4) | Quần váy và bộ đồ | 2 | leggings, tights, sweatpants, suit, uniform | 51.00s |
| [05](05-hoan-canh-phan-1.mp4) | Đồ mặc theo hoàn cảnh | 1 | jacket, coat, raincoat, swimsuit, swimming trunks | 49.33s |
| [06](06-hoan-canh-phan-2.mp4) | Đồ mặc theo hoàn cảnh | 2 | bikini, pajamas, nightdress, bathrobe, underwear | 51.00s |
| [07](07-giay-dep-phan-1.mp4) | Giày dép và tất | 1 | shoes, sneakers, boots, sandals, slippers | 51.67s |
| [08](08-giay-dep-phan-2.mp4) | Giày dép và tất | 2 | flip-flops, socks, high heels, shoelaces, soles | 48.00s |
| [09](09-phu-kien-phan-1.mp4) | Phụ kiện thông dụng | 1 | hat, cap, scarf, gloves, belt | 49.33s |
| [10](10-phu-kien-phan-2.mp4) | Phụ kiện thông dụng | 2 | tie, bow tie, handbag, backpack, sunglasses | 47.67s |
| [11](11-chat-lieu-phan-1.mp4) | Chi tiết và chất liệu | 1 | sleeve, collar, pocket, button, zipper | 46.33s |
| [12](12-chat-lieu-phan-2.mp4) | Chi tiết và chất liệu | 2 | cotton, wool, silk, leather, denim | 55.50s |
| [13](13-mau-sac-phan-1.mp4) | Màu sắc quần áo | 1 | black, white, red, blue, green | 48.50s |
| [14](14-mau-sac-phan-2.mp4) | Màu sắc quần áo | 2 | yellow, pink, brown, gray, purple | 51.00s |
| [15](15-mo-ta-phan-1.mp4) | Mô tả quần áo | 1 | big, small, long, short, tight | 51.00s |
| [16](16-mo-ta-phan-2.mp4) | Mô tả quần áo | 2 | loose, clean, dirty, new, old | 52.83s |
| [17](17-mac-coi-phan-1.mp4) | Mặc và cởi | 1 | wear a coat, put on a shirt, take off your shoes, try on a dress, get dressed | 51.17s |
| [18](18-mac-coi-phan-2.mp4) | Mặc và cởi | 2 | get undressed, button up your shirt, zip up your jacket, roll up your sleeves, tuck in your shirt | 52.33s |
| [19](19-cham-soc-phan-1.mp4) | Chăm sóc và chọn đồ | 1 | wash, dry, fold, hang, iron | 54.17s |
| [20](20-cham-soc-phan-2.mp4) | Chăm sóc và chọn đồ | 2 | mend, sew, pack, choose, buy | 57.50s |
