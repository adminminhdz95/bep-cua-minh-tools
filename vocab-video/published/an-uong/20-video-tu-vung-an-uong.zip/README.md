# 20 video từ vựng về đồ ăn và cảm giác ăn uống

Mỗi video có 5 từ/cụm từ, logo Tiếng Anhh Cùng Minh, cùng giọng ElevenLabs cho câu hỏi tiếng Việt và đáp án tiếng Anh, tiếng tích tắc theo mẫu.

Định dạng 1080×1920, 30fps. Đọc trọn câu hỏi tiếng Việt với tốc độ 92%, sau đó ít nhất 4 giây đếm ngược. Thời lượng tăng để không cắt lời.

| Video | Chủ đề | Phần | Từ vựng | Thời lượng |
|---|---|---|---|---|
| [01](01-mon-an-phan-1.mp4) | Món ăn quen thuộc | 1 | rice, bread, noodles, porridge, soup | 48.00s |
| [02](02-mon-an-phan-2.mp4) | Món ăn quen thuộc | 2 | sandwich, pizza, pasta, salad, dumpling | 50.67s |
| [03](03-trai-cay-phan-1.mp4) | Trái cây | 1 | apple, banana, orange, mango, watermelon | 48.50s |
| [04](04-trai-cay-phan-2.mp4) | Trái cây | 2 | pineapple, strawberry, grape, peach, pear | 47.67s |
| [05](05-rau-cu-phan-1.mp4) | Rau củ | 1 | carrot, potato, tomato, cucumber, onion | 46.67s |
| [06](06-rau-cu-phan-2.mp4) | Rau củ | 2 | garlic, cabbage, spinach, broccoli, mushroom | 45.83s |
| [07](07-thit-ca-phan-1.mp4) | Thịt cá và thực phẩm giàu đạm | 1 | beef, pork, chicken, fish, shrimp | 50.67s |
| [08](08-thit-ca-phan-2.mp4) | Thịt cá và thực phẩm giàu đạm | 2 | crab, squid, salmon, egg, tofu | 46.67s |
| [09](09-do-ngot-phan-1.mp4) | Đồ ngọt và đồ uống | 1 | cake, cookie, chocolate, candy, ice cream | 45.83s |
| [10](10-do-ngot-phan-2.mp4) | Đồ ngọt và đồ uống | 2 | milk, juice, tea, coffee, yogurt | 47.17s |
| [11](11-huong-vi-phan-1.mp4) | Hương vị | 1 | sweet, sour, salty, bitter, spicy | 47.50s |
| [12](12-huong-vi-phan-2.mp4) | Hương vị | 2 | savory, bland, tangy, smoky, minty | 52.33s |
| [13](13-ket-cau-phan-1.mp4) | Kết cấu và chất lượng | 1 | crispy, crunchy, chewy, creamy, juicy | 54.50s |
| [14](14-ket-cau-phan-2.mp4) | Kết cấu và chất lượng | 2 | tender, greasy, fresh, stale, soggy | 51.50s |
| [15](15-cam-giac-an-phan-1.mp4) | Cảm giác khi ăn | 1 | hungry, thirsty, full, stuffed, satisfied | 49.83s |
| [16](16-cam-giac-an-phan-2.mp4) | Cảm giác khi ăn | 2 | peckish, ravenous, nauseous, bloated, disgusted | 49.33s |
| [17](17-hanh-dong-phan-1.mp4) | Hành động ăn uống | 1 | eat, drink, bite, chew, swallow | 43.67s |
| [18](18-hanh-dong-phan-2.mp4) | Hành động ăn uống | 2 | sip, taste, lick, gulp, savor | 56.33s |
| [19](19-bua-an-phan-1.mp4) | Trong bữa ăn | 1 | have breakfast, have lunch, have dinner, have a snack, order food | 48.00s |
| [20](20-bua-an-phan-2.mp4) | Trong bữa ăn | 2 | set the table, share a meal, ask for the bill, pack up the leftovers, lose your appetite | 51.50s |
